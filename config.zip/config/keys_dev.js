module.exports = {
  MONGO_URI: "mongodb+srv://dev:mWqhTAzRxp1xz0jq@stray-jirtj.mongodb.net/dev",
  secretOrKey: "saveastray",
  fbookKey: "af0fd18b3f4c012557b57108d1455d8e",
  fbookClient: "515957642529597"
};