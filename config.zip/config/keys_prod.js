module.exports = {
  MONGO_URI: process.env.MONGO_URI,
  secretOrKey: process.env.SECRET_OR_KEY,
  fbookKey: process.env.FBOOK_KEY,
  fbookClient: process.env.FBOOK_CLIENT
}